//
//  Slider.swift
//  Lesson 7
//
//  Created by Claude RICAUD on 18/11/2015.
//  Copyright © 2015 Claude RICAUD. All rights reserved.
//

import Cocoa

class Slider: NSObject {

    @IBOutlet weak var aLabel: NSTextField!
    @IBOutlet weak var aSlider: NSSlider!
    
    override func awakeFromNib() {
        aSlider.intValue = 25
        aLabel.stringValue = String(aSlider.intValue)
    }
    
    @IBAction func sliderChange(sender: NSSlider) {
        aLabel.stringValue = String(aSlider.intValue)
        
    }
}

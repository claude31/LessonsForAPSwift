//
//  AppController.swift
//  Lesson 2
//
//  Created by Claude RICAUD on 18/11/2015.
//  Copyright © 2015 Claude RICAUD. All rights reserved.
//

import Cocoa

class AppController: NSObject {
    
    @IBOutlet var aLabel: NSTextField!    // label en haut d'écran

    override func awakeFromNib() {
        aLabel.font = NSFont(name: "Herculanum", size: 15)
        aLabel.textColor = NSColor.redColor()
        aLabel.backgroundColor = NSColor.yellowColor()
        aLabel.drawsBackground = true
        aLabel.selectable = true
    }

    @IBAction func sayHello(sender: NSButton) {
     aLabel.stringValue = "Hello Youtube!!!!"
    }
}

//
//  AppController.swift
//  Lesson 19
//
//  Created by Claude RICAUD on 23/11/2015.
//  Copyright © 2015 Claude RICAUD. All rights reserved.
//

import Cocoa

class AppController: NSObject {
    var chekBoxIsEnabled: Bool
    var amount : Int

    override init() {
        self.chekBoxIsEnabled = true
        self.amount = 50
        super.init()
    }
}

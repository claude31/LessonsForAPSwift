//
//  AppController.swift
//  Lesson 18
//
//  Created by Claude RICAUD on 22/11/2015.
//  Copyright © 2015 Claude RICAUD. All rights reserved.
//

import Cocoa

class AppController: NSObject {
    var downloadsController : DownloadsController
    var sliderValue: NSTextField!

    override init() {
        self.downloadsController = DownloadsController()
        super.init()
    }
    
    
    @IBAction func showDownloads(sender: NSMenuItem) {
        
        if (downloadsController.window == nil) {
            downloadsController = DownloadsController(windowNibName: "Downloads")
        }
        downloadsController.showWindow(self)
    }
    
}

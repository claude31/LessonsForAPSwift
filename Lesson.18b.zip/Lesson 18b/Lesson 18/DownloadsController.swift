//
//  DownloadsController.swift
//  Lesson 18
//
//  Created by Claude RICAUD on 22/11/2015.
//  Copyright © 2015 Claude RICAUD. All rights reserved.
//

import Cocoa

class DownloadsController: NSWindowController {

    override func windowDidLoad() {
        super.windowDidLoad()
    
        // Implement this method to handle any initialization after your window controller's window has been loaded from its nib file.
    }

    override init(window: NSWindow?) {
        super.init(window: window)
    }
    
    
//    convenience init(windowNibName: String) {
//        self.init(windowNibName: windowNibName)
//    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

}

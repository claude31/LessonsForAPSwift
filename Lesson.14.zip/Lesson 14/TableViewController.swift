//
//  TableViewController.swift
//  Lesson 14
//
//  Created by Claude RICAUD on 21/11/2015.
//  Copyright © 2015 Claude RICAUD. All rights reserved.
//

import Cocoa

class TableViewController: NSObject, NSTableViewDataSource {

    @IBOutlet weak var tableView: NSTableView!
    var list : [Person] // NSMutableArray
    
     override init () {
        list = [Person]() // list = NSMutableArray()
        super.init()
    }
    
    func numberOfRowsInTableView(tableView: NSTableView) -> Int {
        return list.count
    }

    func tableView(tableView: NSTableView, objectValueForTableColumn tableColumn: NSTableColumn?, row: Int) -> AnyObject? {
//        var p: Person
        let p = list[row]
        let identifier : String = (tableColumn?.identifier)!
        let s = p.valueForKey(identifier as String)
        return s
//        return list[row]
    }
    
    func tableView(tableView: NSTableView, setObjectValue object: AnyObject?, forTableColumn tableColumn: NSTableColumn?, row: Int) {
        let p = list[row]
        let identifier : String = (tableColumn?.identifier)!
        p.setValue(object, forKey: identifier as String)
        tableView.reloadData()
    }
    
//    func tableView(tableView: NSTableView, viewForTableColumn tableColumn: NSTableColumn?, row: Int) -> NSView? {
//    }
    
    
    @IBAction func add(sender: NSButton) {
        let p = Person(name: "aName", age: 20)
        // list.addObject(p)
        self.list.append(p)
        tableView.reloadData()
    }
    
    @IBAction func remove(sender: AnyObject) {
        let row = tableView.selectedRow
        tableView.abortEditing()   // éviter bug si delete alors que edition en cours
        if row >= 0 {
            list.removeAtIndex(row)
            tableView.reloadData()
        }
    }
        
}

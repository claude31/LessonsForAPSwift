//
//  Person.swift
//  Lesson 14
//
//  Created by Claude RICAUD on 21/11/2015.
//  Copyright © 2015 Claude RICAUD. All rights reserved.
//

import Cocoa

class Person: NSObject {
    var name : String
    var age : Int
    
    override init() {
        self.name = String()
        self.name = "Yoda"
        self.age = 300
        super.init()
    }

    init(name: String, age: Int) {
        self.name = name
        self.age = age
    }

    required convenience init?(coder decoder: NSCoder) {
        self.init()
        self.name = decoder.decodeObjectForKey("name") as! String
        self.age = decoder.decodeObjectForKey("age") as! Int
    }

}

// MARK: - NSCoding to allow storing data

extension Person: NSCoding {
    func encodeWithCoder(coder: NSCoder) {
        coder.encodeObject(self.name, forKey: "name")
        coder.encodeObject(Double(self.age), forKey: "age")
    }

}


//
//  SuperPopUpButton.swift
//  Lesson 9
//
//  Created by Claude RICAUD on 18/11/2015.
//  Copyright © 2015 Claude RICAUD. All rights reserved.
//

import Cocoa

class SuperPopUpButton: NSObject {
    @IBOutlet weak var popUp: NSPopUpButton!
    @IBOutlet weak var textField: NSTextField!
    @IBOutlet weak var label: NSTextField!

    @IBAction func add(sender: NSButton) {
        if textField.stringValue == "" {
            popUp.addItemsWithTitles(["------"])
        } else {
            popUp.addItemsWithTitles([textField.stringValue])
        }
    }
    
    @IBAction func update(sender: NSPopUpButton) {
        label.stringValue = popUp.titleOfSelectedItem!
    }
    
}

//
//  AppController.swift
//  Lesson 16
//
//  Created by Claude RICAUD on 22/11/2015.
//  Copyright © 2015 Claude RICAUD. All rights reserved.
//

import Cocoa

class AppController: NSObject {

    @IBOutlet weak var label: NSTextField!
    
    @IBAction func sayHello(sender: NSMenuItem) {
        label.stringValue = "Hello"
    }
    
    @IBAction func sayGoodBye(sender: NSMenuItem) {
        label.stringValue = "GoodBye"
    }
}
